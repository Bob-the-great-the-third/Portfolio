import { Component } from '@angular/core';

@Component({
  selector: 'app-who-am-i',
  standalone: true,
  templateUrl: './who-am-i.component.html',
  styleUrl: './who-am-i.component.css',
})
export class WhoAmIComponent {

}
