export class Status {
    constructor(
        public id:number = 0,
        public status:string="Prévu",
    ){}
}