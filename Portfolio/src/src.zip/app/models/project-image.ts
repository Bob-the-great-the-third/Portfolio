export class ProjectImage {
    constructor(
        public id:number = 0,
        public project_id:number=0,
        public img_path:string="",
    ){}
}
