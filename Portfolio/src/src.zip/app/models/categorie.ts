export class Categorie {
    constructor(
        public id:number = 0,
        public categ:string="Perso",
    ){}
}