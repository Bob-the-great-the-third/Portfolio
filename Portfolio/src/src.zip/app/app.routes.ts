import { Routes } from '@angular/router';
import { MainPageComponent } from './main-page/main-page/main-page.component';

export const routes: Routes = [
  {path:"",component:MainPageComponent},
  // Ajoute tes routes ici selon ton app-routing.module.ts actuel
  // Exemple :
  // { path: '', redirectTo: '/menus', pathMatch: 'full' },
  // { path: 'menus', component: MenuListComponent },
  // { path: 'menus/:id', component: MenuDetailComponent },
  // { path: 'menus/:id/edit', component: MenuEditComponent },
  // etc.
];